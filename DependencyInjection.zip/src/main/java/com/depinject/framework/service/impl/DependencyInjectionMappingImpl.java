package com.depinject.framework.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.depinject.framework.service.DependencyInjectionMapping;


/**
 * Abstract class to configure and retrieve proper dependency injection mapping.
 *
 * @author srangam
 * @version 1.0
 * 
*/


public abstract class DependencyInjectionMappingImpl implements DependencyInjectionMapping {
	private final Map<Class<?>, Class<?>> classMap = new HashMap<Class<?>, Class<?>>();

    protected <T> void createMapping(final Class<T> baseClass, final Class<? extends T> subClass) {
        classMap.put(baseClass, subClass.asSubclass(baseClass));
    }

    public <T> Class<? extends T> getMapping(final Class<T> type) {
        final Class<?> implementation = classMap.get(type);
        if (implementation == null) {
            throw new IllegalArgumentException("Couldn't find the mapping (subclass / implementation) for : " + type);
        }
        return implementation.asSubclass(type);
    }
}
