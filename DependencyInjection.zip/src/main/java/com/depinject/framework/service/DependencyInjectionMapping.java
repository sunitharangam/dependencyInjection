package com.depinject.framework.service;
/**
 * interface to configure dependency injection mapping.
 *
 * @author srangam
 *
 */
public interface DependencyInjectionMapping {
	void configure();

    <T> Class<? extends T> getMapping(Class<T> type);
}
