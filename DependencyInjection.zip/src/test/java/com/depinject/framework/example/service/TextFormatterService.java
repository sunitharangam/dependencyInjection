package com.depinject.framework.example.service;

public interface TextFormatterService {
	String format(String text);
}
