package com.depinject.framework.example.service.impl;

import com.depinject.framework.example.service.CalculatorService;

public class SubtractionCalculatorServiceImpl implements CalculatorService {

	public int calculate(int firstNumber, int secondNumber) {
		return firstNumber - secondNumber;
	}

}