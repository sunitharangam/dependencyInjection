package com.depinject.framework.example;

import com.depinject.framework.example.service.CalculatorService;
import com.depinject.framework.example.service.TextFormatterService;
import com.depinject.framework.example.service.impl.AdditionCalculatorServiceImpl;
import com.depinject.framework.example.service.impl.SimpleTextFormatterServiceImpl;
import com.depinject.framework.service.impl.DependencyInjectionMappingImpl;

public class DependencyInjectionConfig extends DependencyInjectionMappingImpl {
	public void configure() {
        createMapping(CalculatorService.class, AdditionCalculatorServiceImpl.class);
        createMapping(TextFormatterService.class, SimpleTextFormatterServiceImpl.class);
    }
}
