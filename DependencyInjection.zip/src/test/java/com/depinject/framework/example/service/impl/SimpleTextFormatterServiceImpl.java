package com.depinject.framework.example.service.impl;

import com.depinject.framework.example.service.TextFormatterService;

public class SimpleTextFormatterServiceImpl implements TextFormatterService {

	public String format(String text) {
		return "Simple text: " + text;
	}

}
