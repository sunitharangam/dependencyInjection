package com.depinject.framework.example.service.impl;

import com.depinject.framework.example.service.TextFormatterService;

public class PrettyTextFormatterServiceImpl implements TextFormatterService {

	public String format(String text) {
		return "Pretty text: <" + text + ">";
	}

}
