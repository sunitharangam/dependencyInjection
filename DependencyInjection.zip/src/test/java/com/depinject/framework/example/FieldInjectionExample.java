package com.depinject.framework.example;

import com.depinject.framework.annotation.InjectAnnotation;
import com.depinject.framework.example.service.CalculatorService;
import com.depinject.framework.example.service.TextFormatterService;

public class FieldInjectionExample {

	@InjectAnnotation
	private CalculatorService calculatorService;

	@InjectAnnotation
	private TextFormatterService textFormatterService;

	public CalculatorService getCalculatorService() {
		return calculatorService;
	}

	public void setCalculatorService(CalculatorService calculatorService) {
		this.calculatorService = calculatorService;
	}

	public TextFormatterService getTextFormatterService() {
		return textFormatterService;
	}

	public void setTextFormatterService(TextFormatterService textFormatterService) {
		this.textFormatterService = textFormatterService;
	}
	public String processNumbers(int firstNumber, int secondNumber) {
		int number = calculatorService.calculate(firstNumber, secondNumber);
		return textFormatterService.format(String.valueOf(number));
	}
}