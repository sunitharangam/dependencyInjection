package com.depinject.framework.example;

import org.junit.Test;

import com.depinject.framework.annotation.InjectAnnotation;
import com.depinject.framework.example.service.CalculatorService;
import com.depinject.framework.example.service.TextFormatterService;

public class ConstructorInjectionExample {

	private final CalculatorService calculatorService;
	private final TextFormatterService textFormatterService;

		
	@InjectAnnotation
	public ConstructorInjectionExample(CalculatorService calculatorService, TextFormatterService textFormatterService) {
		this.calculatorService = calculatorService;
		this.textFormatterService = textFormatterService;
	}


	public String processNumbers(int firstNumber, int secondNumber) {
		int number = calculatorService.calculate(firstNumber, secondNumber);
		return textFormatterService.format(String.valueOf(number));
	}
	
	/*@Test
	public void processNumbers() {
		int firstNumber = 10;
		int secondNumber = 20;
		int number = calculatorService.calculate(firstNumber, secondNumber);
		System.out.println("Constructor Injection::: "+textFormatterService.format(String.valueOf(number)));
	}*/
}