package com.depinject.framework.example;

import com.depinject.framework.DependencyInjection;
import com.depinject.framework.DependencyInjectionFramework;

public class SampleAppToTest {
	public static void main(final String[] args) throws Exception {
        final DependencyInjectionFramework dependencyInjectionFramework = DependencyInjection.getFramework(new DependencyInjectionConfig());
        final ConstructorInjectionExample constructorInjectionExample = (ConstructorInjectionExample) dependencyInjectionFramework.inject(ConstructorInjectionExample.class);
        int firstNumber = 10;
		int secondNumber = 20;
		String number = constructorInjectionExample.processNumbers(firstNumber, secondNumber);
		System.out.println("Constructor Injection::: "+number);
    }
}
