package com.depinject.framework.example.service;

public interface CalculatorService {
	int calculate(int firstNumber, int secondNumber);
}
