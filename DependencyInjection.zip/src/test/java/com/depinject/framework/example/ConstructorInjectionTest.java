package com.depinject.framework.example;

import org.junit.Test;

import com.depinject.framework.example.service.CalculatorService;
import com.depinject.framework.example.service.TextFormatterService;
import com.depinject.framework.example.service.impl.AdditionCalculatorServiceImpl;
import com.depinject.framework.example.service.impl.SimpleTextFormatterServiceImpl;

public class ConstructorInjectionTest {
	private final CalculatorService calculatorService = new AdditionCalculatorServiceImpl();
	private final TextFormatterService textFormatterService = new SimpleTextFormatterServiceImpl();
	ConstructorInjectionExample constructorInjectionExample = new ConstructorInjectionExample(calculatorService,textFormatterService);
	
	@Test
	public void processNumbers() {
		int firstNumber = 10;
		int secondNumber = 20;
		String number = constructorInjectionExample.processNumbers(firstNumber, secondNumber);
		System.out.println("Constructor Injection::: "+number);
	}
}
